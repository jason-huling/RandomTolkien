#ifndef NGRAM_HASH_H
#define NGRAM_HASH_H

#include <stdint.h>

#include "lex.h"

tok_t get_token(wordlist_t *word, const int num);

#endif

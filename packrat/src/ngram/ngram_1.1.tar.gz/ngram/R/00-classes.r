setClass("ngram", 
  representation(
    str_ptr="externalptr",
    strlen="integer",
    n="integer",
    ng_ptr="externalptr",
    ngsize="integer",
    wl_ptr="externalptr"
  )
)



#' @png
#' @get /png
function() {
  plot(1:10)
}

#' @jpeg
#' @get /jpeg
function() {
  plot(1:10)
}
